export const inputCheck = /^[가-힣]{1,6}$/
