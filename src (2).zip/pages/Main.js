import React from "react"
import { BasketList } from "../components/BasketList"

export const Main = (props) => {
  return (
    <>
      <BasketList />
    </>
  )
}

